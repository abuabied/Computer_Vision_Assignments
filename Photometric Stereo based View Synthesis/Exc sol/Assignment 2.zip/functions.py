import numpy as np
import cv2
from scipy import ndimage
from scipy.ndimage import median_filter


def census_transform(image):
    # image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    height, width = image.shape
    census_transform = np.empty((height, width), dtype=np.ndarray)
    for y in range(height):
        for x in range(width):
            center_value = image[y, x]
            census_values = []
            for dy in range(-2, 3):
                for dx in range(-3, 2):
                    if 0 <= y + dy < height and 0 <= x + dx < width:
                        if dy != 0 or dx != 0:
                            if center_value < image[y + dy, x + dx]:
                                census_values.append(0)
                            else:
                                census_values.append(1)
            # print(census_values)
            census_transform[y, x] = census_values

    return census_transform


def calculate_disparity(census1, census2, max_disparity, left=True):
    height, width = census1.shape
    depth = int(max_disparity)
    disparity_map = np.full((height, width, depth), 2 ** 10, dtype=np.int32)
    for y in range(height):
        for x in range(width):
            i = 0
            if not left:
                rng = range(x, min(width, x + depth))
            else:
                rng = range(max(0, x - depth + 1), x + 1)
                rng = np.flip(rng)
            for x_shift in rng:
                # print(f"depth - {x_shift - x} - and comparing - {[x, x_shift]}" )
                if not (census1[y, x] is None) and not (census2[y, x_shift] is None):
                    hamming_dist = calc_hamming_dis(census1[y, x], census2[y, x_shift])
                    # print(hamming_dist)
                    disparity_map[y, x, i] = hamming_dist
                    i += 1
        print(y)

    disparity_map = average_3d_disparity(disparity_map)

    return disparity_map


def average_3d_disparity(disparity_map):
    height, width, depth = disparity_map.shape
    agg_cost_volume = np.zeros((depth, height, width), dtype=np.int32)

    for d in range(depth):
        print(d)
        for y in range(height):
            for x in range(width):
                start_row = max(y - 1, 0)
                end_row = min(y + 2, height)
                start_col = max(x - 1, 0)
                end_col = min(x + 2, width)
                values = disparity_map[start_row:end_row, start_col:end_col, d]
                if 2 ** 10 in values:
                    values = values[values >= 2 ** 10]
                avrg = np.mean(values)
                agg_cost_volume[d, y, x] = avrg

    return agg_cost_volume


def find_min_diparity(disparity_map):
    depth, height, width = disparity_map.shape
    final_disparity_map = np.zeros((height, width), dtype=np.int32)

    for y in range(height):
        for x in range(width):
            min_dis = disparity_map[0, y, x]
            min_d = 0
            for d in range(1, depth):
                if min_dis > disparity_map[d, y, x]:
                    min_dis = disparity_map[d, y, x]
                    min_d = d
            final_disparity_map[y, x] = int(min_d)

    return final_disparity_map


def get_depth_map(disparity_map, focal_length, baseline=0.1):
    height, width = disparity_map.shape
    depth_map = np.zeros((height, width), dtype=np.float32)

    for y in range(height):
        for x in range(width):
            disparity = disparity_map[y, x]

            if disparity != 0:
                depth = (baseline * focal_length) / disparity
                depth_map[y, x] = depth

    return depth_map


def disparity_consistency_check(disparity_map1, disparity_map2, threshold=5, left=True):
    # Perform consistency check
    height, width = disparity_map1.shape

    for y in range(height):
        for x in range(width):
            # Retrieve disparity values from both maps
            disp1 = int(disparity_map1[y, x])
            if left:
                if x - disp1 >= 0:
                    disp2 = int(disparity_map2[y, x - disp1])
                else:
                    # disparity_map1[y, x] = 0
                    continue
            else:
                if x + disp1 < width:
                    disp2 = disparity_map2[y, x + disp1]
                else:
                    # disparity_map1[y, x] = 0
                    continue

            # Compute the absolute difference between disparities
            diff = abs(disp1 - disp2)

            # Check if the difference is below the threshold
            if diff > threshold:
                # Consistent match
                disparity_map1[y, x] = 0

    return disparity_map1


def calcAndsave_disparityAndDepth(im_left, im_right, max_disparity, focal_length, save_path=""):
    census_left = census_transform(im_left)
    census_right = census_transform(im_right)
    print("Calculated census")

    disparity_3d_left = calculate_disparity(census_left, census_right, max_disparity, left=True)
    print("Calculated 3d disparity map")
    disparity_map_left = find_min_diparity(disparity_3d_left)
    print("Calculated 2d (min) disparity map left")

    disparity_3d_right = calculate_disparity(census_right, census_left, max_disparity, left=False)
    print("Calculated 3d disparity map right")
    disparity_map_right = find_min_diparity(disparity_3d_right)
    print("Calculated 2d (min) disparity map right")

    disparity_map_left = disparity_consistency_check(disparity_map_left, disparity_map_right, threshold=3, left=True)
    disparity_map_right = disparity_consistency_check(disparity_map_right, disparity_map_left, threshold=3, left=False)
    np.savetxt(f'{save_path}disp_right.txt', disparity_map_right, delimiter=',', fmt='%s')
    np.savetxt(f"{save_path}disp_left.txt", disparity_map_left, delimiter=',', fmt='%s')
    print("Consistency check done")

    im_disp_left = ((disparity_map_left / max_disparity) * 255).astype(np.uint8)
    im_disp_left = cv2.equalizeHist(im_disp_left)
    im_disp_right = ((disparity_map_right / max_disparity) * 255).astype(np.uint8)
    im_disp_right = cv2.equalizeHist(im_disp_right)
    im_disp_left = median_filter(im_disp_left, size=3)
    im_disp_right = median_filter(im_disp_right, size=3)
    cv2.imwrite(f"{save_path}disp_left.jpg", im_disp_left, [cv2.IMWRITE_JPEG_QUALITY, 90])
    cv2.imwrite(f"{save_path}disp_right.jpg", im_disp_right, [cv2.IMWRITE_JPEG_QUALITY, 90])
    print("Saved disparity map")

    depth_map_left = get_depth_map(disparity_map_left, focal_length)
    depth_map_right = get_depth_map(disparity_map_right, focal_length)
    np.savetxt(f'{save_path}depth_left.txt', depth_map_left, delimiter=',', fmt='%s')
    np.savetxt(f'{save_path}depth_right.txt', depth_map_right, delimiter=',', fmt='%s')
    print("Calculated depth map")

    im_depth_left = cv2.equalizeHist(((depth_map_left / np.max(depth_map_left)) * 255).astype(np.uint8))
    im_depth_right = cv2.equalizeHist(((depth_map_right / np.max(depth_map_left)) * 255).astype(np.uint8))
    im_depth_left = median_filter(im_depth_left, size=3)
    im_depth_right = median_filter(im_depth_right, size=3)
    cv2.imwrite(f"{save_path}depth_left.jpg", im_depth_left, [cv2.IMWRITE_JPEG_QUALITY, 90])
    cv2.imwrite(f"{save_path}depth_right.jpg", im_depth_right, [cv2.IMWRITE_JPEG_QUALITY, 90])
    print("Saved depth image")

    return depth_map_left


def reproject_to_3d(left_image, K, D):
    image_height, image_width = left_image.shape[:2]
    points_3d = np.zeros((image_height, image_width, 3), dtype=np.float32)

    for v in range(image_height):
        for u in range(image_width):
            depth = D[v, u]
            point_2d = np.array([[u], [v], [1]], dtype=np.float32)
            point_3d = np.matmul(np.linalg.inv(K), point_2d) * depth
            points_3d[v, u] = point_3d.flatten()

    return points_3d


def project_to_2d(points_3d, left_image, P):
    image_height, image_width = left_image.shape[:2]
    synthesized_image = np.zeros((image_height, image_width, 3), dtype=np.uint8)

    for v in range(image_height):
        for u in range(image_width):
            point_3d = points_3d[v, u]
            point_3d_homogeneous = np.append(point_3d, 1.0)
            point_3d_homogeneous = point_3d_homogeneous.reshape((4, 1))
            point_2d = np.matmul(P, point_3d_homogeneous)

            if point_2d[2] != 0:
                point_2d /= point_2d[2]
                u_proj, v_proj = np.round(point_2d[:2]).astype(int)
                if 0 <= u_proj < image_width and 0 <= v_proj < image_height:
                    synthesized_image[v_proj, u_proj] = left_image[v, u]

    return synthesized_image


def synth_camera_poses(K, D, left_image, num_poses=11, axis_shift=0.01, save_path="", blur=-1):
    RT = np.array([[1, 0, 0, 0],
                   [0, 1, 0, 0],
                   [0, 0, 1, 0]])
    translationM = np.array([[1, 0, 0, axis_shift],
                             [0, 1, 0, 0],
                             [0, 0, 1, 0],
                             [0, 0, 0, 1]])
    for i in range(num_poses):
        translationM[0, 3] = -1 * axis_shift * i
        P = np.matmul(K, np.matmul(RT, translationM))
        points_3d = reproject_to_3d(left_image, K, D)
        synthesized_image = project_to_2d(points_3d, left_image, P)
        if blur > 0:
            synthesized_image = filter_med(synthesized_image, blur=blur)
        cv2.imwrite(f"{save_path}synth_{i + 1:02d}.jpg", synthesized_image, [cv2.IMWRITE_JPEG_QUALITY, 90])
        print(f"saved synth_{i + 1:02d}")


def get_intrinsic_mat(path):
    with open(path, 'r') as f:
        # Read the contents of the file
        contents = f.read()

    # Split the contents of the file into rows
    rows = contents.split('\n')

    matrix = []
    for row in rows:
        values = row.split('\t')
        tmp = []
        for value in values:
            if value != '':
                tmp.append(np.float32(value))
        matrix.append(np.array(tmp))

    return (np.array(matrix[:3])).astype(np.float32)


def get_depth_mat(path):
    with open(path, 'r') as f:
        # Read the contents of the file
        contents = f.read()

    # Split the contents of the file into rows
    rows = contents.split('\n')
    if rows is not None:
        rows.pop()
        length = len(rows[0])

    matrix = []
    for row in rows:
        values = row.split(',')
        tmp = []
        for value in values:
            if value != '':
                tmp.append(np.float32(value))
        matrix.append(np.array(tmp))
    return (np.array(matrix[:length])).astype(np.float32)


def get_max_disparity(path):
    with open(path, 'r') as f:
        # Read the contents of the file
        contents = f.read()

    # Split the contents of the file into rows
    rows = contents.split('\n')
    if rows is not None:
        rows.pop()

    max_dis = np.float32(rows[0])
    return max_dis


def get_focal_length(intrinsic_matrix):
    focal_length_x = intrinsic_matrix[0, 0]
    return focal_length_x


def calc_hamming_dis(desc1, desc2):
    size_diff = abs(len(desc1) - len(desc2))

    if len(desc1) < len(desc2):
        resized_array1 = np.concatenate((desc1, np.logical_not(desc2[len(desc1):]).astype(int)))
        resized_array2 = desc2
    else:
        resized_array1 = desc1
        resized_array2 = np.concatenate((desc2, np.logical_not(desc1[len(desc2):]).astype(int)))

    result = np.bitwise_xor(resized_array1, resized_array2)

    return np.sum(result)


def windowed_average(matrix, window_size):
    kernel = np.ones((window_size, window_size)) / (window_size ** 2)
    result = np.convolve(matrix.flatten(), kernel.flatten(), mode='same').reshape(matrix.shape)
    return result


def filter_med(im, blur=3):
    filtered_matrix = np.zeros_like(im)
    for j in range(3):
        filtered_matrix[..., j] = ndimage.median_filter(im[..., j], size=blur)
    return filtered_matrix
