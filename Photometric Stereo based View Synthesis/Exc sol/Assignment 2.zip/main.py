import os

import cv2
import numpy as np
from scipy import ndimage

import functions
from scipy.ndimage import median_filter, gaussian_filter

SET_PATH = 'data\set_'

if __name__ == '__main__':
    for i in range(1, 6):
        save_path = f"results/set_{str(i)}/"
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        directory_path = f"{SET_PATH + str(i)}"
        left_image_path = f"{directory_path}/im_left.jpg"
        right_image_path = f"{directory_path}/im_right.jpg"
        K_path = f"{directory_path}/K.txt"
        max_disp_path = f"{directory_path}/max_disp.txt"

        print(f"Working in set {str(i)}")
        K = functions.get_intrinsic_mat(path=K_path)
        max_disp = functions.get_max_disparity(path=max_disp_path)
        focal_length = functions.get_focal_length(K)

        im_left = cv2.imread(left_image_path, cv2.IMREAD_GRAYSCALE)
        im_right = cv2.imread(right_image_path, cv2.IMREAD_GRAYSCALE)

        D = functions.calcAndsave_disparityAndDepth(im_left, im_right, max_disp, focal_length, save_path=save_path)
        im_left = cv2.imread(left_image_path)
        functions.synth_camera_poses(K, D, im_left, save_path=save_path, blur=3)
