import cv2
import numpy as np
import random



def point_matching(im1, im2, maxPoints=-1, useGrayScale=True, p_matching_num=1, ratio=0.7):
    if useGrayScale:
        im1 = cv2.cvtColor(im1, cv2.COLOR_BGR2GRAY)
        im2 = cv2.cvtColor(im2, cv2.COLOR_BGR2GRAY)
    siftObject = cv2.SIFT_create()
    keypoint1, descriptor1 = siftObject.detectAndCompute(im1, None)
    keypoint2, descriptor2 = siftObject.detectAndCompute(im2, None)
    if maxPoints != -1:
        if len(keypoint1) > maxPoints:
            keypoint1 = np.random.choice(keypoint1, size=maxPoints, replace=False)
        if len(keypoint2) > maxPoints:
            keypoint2 = np.random.choice(keypoint2, size=maxPoints, replace=False)
    points, info = get_matches(keypoint1, keypoint2, descriptor1, descriptor2, ratio, max_matches=maxPoints)
    img3 = cv2.drawMatches(im1, keypoint1, im2, keypoint2, info[:50], im2, flags=2)
    # cv2.imwrite("imageMatch" + str(p_matching_num) + ".jpg", img3, [cv2.IMWRITE_JPEG_QUALITY, 90])
    return points, info


def get_matches(pnts1, pnts2, desc1, desc2, ratio, max_matches=-1):
    N = len(pnts1)
    M = len(pnts2)
    good_matches = []
    good_matches_pnts = []
    count = 0

    for i in range(N):
        # normalize vector
        # tmp = np.linalg.norm(desc1[i])
        # if tmp != 0:
        #     desc1[i] = np.divide(desc1[i], tmp)
        #
        # tmp = np.linalg.norm(desc2[0])
        # if tmp != 0:
        #     desc2[0] = np.divide(desc2[0], tmp)
        #
        # tmp = np.linalg.norm(desc2[1])
        # if tmp != 0:
        #     desc2[1] = np.divide(desc2[1], tmp)

        # initiate closest and 2nd closes matches
        best_match = 0
        scnd_best_match = 1
        desc_dif = np.linalg.norm(desc1[i] - desc2[0])
        scnd_desc_dif = np.linalg.norm(desc1[i] - desc2[1])
        if desc_dif > scnd_desc_dif:
            desc_dif, scnd_desc_dif = scnd_desc_dif, desc_dif
            best_match, scnd_best_match = scnd_best_match, best_match
        for j in range(2, M):
            # normalize vector
            # tmp = np.linalg.norm(desc2[j])
            # if tmp != 0:
            #     desc2[j] = np.divide(desc2[j], tmp)
            cur_dif = np.linalg.norm(desc1[i] - desc2[j])
            if cur_dif <= desc_dif:
                scnd_desc_dif = desc_dif
                desc_dif = cur_dif
                scnd_best_match = best_match
                best_match = j
            elif cur_dif < scnd_desc_dif:
                scnd_desc_dif = cur_dif
                scnd_best_match = j

        # check if the match is good enough
        theta = desc_dif / scnd_desc_dif
        if theta < ratio:
            count += 1
            good_matches.append(cv2.DMatch(_queryIdx=i, _trainIdx=best_match, _distance=desc_dif))
            good_matches_pnts.append([pnts1[i], pnts2[best_match]])

    return good_matches_pnts, good_matches


def get_transform_mat(key_points, ITERS=1000, affine=True, min_inlrs_prcntg=0.7, satisfying_inlrs_prcntg=0.85,
                      inlrs_dist=0.9):
    if affine:
        if len(key_points) < 3:
            print("Not enough matching points to find matrix")
            return None
        K = 3
    else:
        if len(key_points) < 4:
            print("Not enough matching points to find matrix")
            return None
        K = 4

    best_mat = None
    best_count = 0

    for i in range(ITERS):
        kps = random.sample(key_points, K)
        kp1 = np.float32([[elem[0].pt[0], elem[0].pt[1]] for elem in kps])
        kp2 = np.float32([[elem[1].pt[0], elem[1].pt[1]] for elem in kps])

        if affine:
            matrix = cv2.getAffineTransform(kp1, kp2)
        else:
            matrix, status = cv2.findHomography(kp1, kp2)

        tmp, in_points = calc_inliers(matrix, key_points, inlrs_dist,affine=affine)
        if min_inlrs_prcntg * len(key_points) < tmp:
            if tmp > best_count:
                best_count = tmp
                best_mat = matrix
            if best_count >= satisfying_inlrs_prcntg * len(key_points):
                return best_mat
    if best_mat is None:
        print("Could not find a good matrix")
    return best_mat


def calc_inliers(matrix, key_points, threshold, affine=True):
    if matrix is None:
        return 0, []
    kp1 = np.float32([[elem[0].pt[0], elem[0].pt[1]] for elem in key_points])
    kp2 = np.float32([[elem[1].pt[0], elem[1].pt[1]] for elem in key_points])
    if matrix.shape[0] < 3:
        matrix = np.vstack((matrix, [0, 0, 1]))
    new_points = []
    i = -1
    for point in kp1:
        i += 1
        p1 = [(point[0], point[1])]
        p2 = cv2.perspectiveTransform(np.array([p1]), matrix)[0][0]
        x1_dst, x2_dst = p2[0], p2[1]
        new_points.append([x1_dst, x2_dst])
        # print("-----")
        # print("expected:  ", [kp2[i][0], kp2[i][1]])
        # print("got     :  ", [x1_dst, x2_dst])
        # print("-----")
    count = 0
    in_points = []
    distances = new_points - kp2
    for i in range(len(distances)):
        distance = np.linalg.norm(np.sqrt(distances[i]**2))
        # print(distance)
        if distance < threshold:
            count += 1
            in_points.append(key_points[i])
    return count, in_points


def get_first_mat(path):
    with open(path, 'r') as f:
        # Read the contents of the file
        contents = f.read()

    # Split the contents of the file into rows
    rows = contents.split('\n')

    # Split each row into values and convert to integers
    matrix = []
    for row in rows:
        values = row.split('\t')
        tmp = []
        for value in values:
            if value != '':
                tmp.append(np.float32(value))
        matrix.append(np.array(tmp))

    return np.array(matrix[:3])


def get_dims(str):
    arr = str.split("_")
    w = int(arr[8])
    h = int(arr[5])
    return w, h

# Function to assemble puzzle pieces using affine transformation
def assemble_puzzle(puzzle_pieces, init_mat=None, w=100, h=100, ratio=0.5, min_inlrs_prcntg=0.7,
                    affine=True, satisfying_inlrs_prcntg=0.85, inlrs_dist=0.9, line_fill_thresh=0, sol_path=None):
    # Start with the first piece
    used_pieces = 0
    if not (init_mat is None):
        puzzle_pieces[0][1] = cv2.warpPerspective(puzzle_pieces[0][1], init_mat.astype(np.float32), (w, h),
                                                  flags=cv2.INTER_LINEAR)
        cv2.imwrite(str(sol_path) + "relative_1_p.jpeg", puzzle_pieces[0][1], [cv2.IMWRITE_JPEG_QUALITY, 90])
        used_pieces = 1

    assembled_puzzle = puzzle_pieces[0][1]
    used = [0]
    iters = round(.3 * len(puzzle_pieces))
    no_change = False
    while len(used) < len(puzzle_pieces) and iters > 0 and not no_change:
        no_change = True
        # Loop over the remaining pieces
        for i in range(1, len(puzzle_pieces)):
            if not (i in used):
                print("working with piece: " + str(i+1) + " - Iters left: " + str(iters))

                m_points, info = point_matching(puzzle_pieces[i][1], assembled_puzzle, p_matching_num=i + 1,
                                                ratio=ratio)
                mat = get_transform_mat(m_points, min_inlrs_prcntg=min_inlrs_prcntg, affine=affine, ITERS=750,
                                        satisfying_inlrs_prcntg=satisfying_inlrs_prcntg, inlrs_dist=inlrs_dist)

                if not (mat is None):
                    if affine:
                        warped_piece = cv2.warpAffine(puzzle_pieces[i][1], mat, (w, h), flags=cv2.INTER_CUBIC)
                    else:
                        warped_piece = cv2.warpPerspective(puzzle_pieces[i][1], mat, (w, h), flags=cv2.INTER_CUBIC)
                    cv2.imwrite(str(sol_path) + "relative_" + str(puzzle_pieces[i][0] + 1) + "_p.jpeg",
                                warped_piece, [cv2.IMWRITE_JPEG_QUALITY, 90])
                    for i1 in range(assembled_puzzle.shape[0]):
                        for j1 in range(assembled_puzzle.shape[1]):
                            if np.all(assembled_puzzle[i1][j1] <= line_fill_thresh):
                                assembled_puzzle[i1][j1] += warped_piece[i1][j1]
                    used_pieces += 1
                    no_change = False
                    used.append(i)
        iters -= 1

    return assembled_puzzle, used_pieces


def segment_images(images):
    gray_images = [cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) for img in images]

    coverage = sum(gray_images) / len(gray_images)

    cmap = cv2.applyColorMap((coverage * 255).astype(np.uint8), cv2.COLORMAP_JET)

    heatmap = np.zeros((*coverage.shape, 4), dtype=np.uint8)
    heatmap[..., :3] = cmap[..., :3]
    heatmap[..., 3] = (coverage * 255 * (coverage / coverage.max())).astype(np.uint8)

    return heatmap

