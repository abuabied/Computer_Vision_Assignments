import functions
import os
import cv2

AFFINE_MAIN_PATH = 'puzzles/puzzle_affine_'
HOMOGRAPHY_MAIN_PATH = 'puzzles/puzzle_homography_'


def solve_puzzle_files(path=None, start=1, end=11, one_puzzle=False, affine=True, ratio=0.4, min_inlrs_prcntg=0.85,
                       satisfying_inlrs_prcntg=0.95, inlrs_dist=0.7,new_puzzle=False):
    if new_puzzle:
        print("puzzle in " + str(path))
        for x in os.listdir(path):
            if x.endswith('.txt'):
                mat_txt = x
        init_mat = functions.get_first_mat(path + '/' + mat_txt)
        init_mat = init_mat[:3]
        w, h = functions.get_dims(mat_txt)

        print("final size: " + str(w) + "x" + str(h))
        path += '/pieces'
        imgs = os.listdir(path)
        pieces_number = len(imgs)
        piece_list = []
        for i in range(pieces_number):
            im = cv2.imread(path + '/piece_' + str(i + 1) + '.jpg')
            piece_list.append([i, im])
        print("got " + str(len(imgs)) + " puzzle pieces")

        if affine:
            newpath = 'results/new_puzzle_affine/'
        else:
            newpath = 'results/new_puzzle_homography/'
        if not os.path.exists(newpath):
            os.makedirs(newpath)

        im, pieces_used = functions.assemble_puzzle(piece_list, ratio=ratio, min_inlrs_prcntg=min_inlrs_prcntg,
                                                    satisfying_inlrs_prcntg=satisfying_inlrs_prcntg,
                                                    inlrs_dist=inlrs_dist, affine=affine, init_mat=init_mat,
                                                    w=w, h=h, sol_path=newpath)
        relative_places = []
        for relative in os.listdir(newpath):
            im_name = relative
            if 'relative' in im_name:
                im = cv2.imread(str(newpath + im_name))
                relative_places.append(im)
        coverage = functions.segment_images(relative_places)
        cv2.imwrite(newpath + "coverage.jpeg",
                    coverage, [cv2.IMWRITE_JPEG_QUALITY, 90])

        cv2.imwrite(newpath + "solution_" + str(pieces_used) + "_" + str(pieces_number) + ".jpeg",
                    im, [cv2.IMWRITE_JPEG_QUALITY, 90])
        print("saved solution image for puzzle")
        return

    if one_puzzle:
        end = start + 1
    for file_num in range(start, end):
        print("puzzle " + str(file_num))
        pieces_path = path + str(file_num)

        mat_txt = ""
        for x in os.listdir(pieces_path):
            if x.endswith('.txt'):
                mat_txt = x
        init_mat = functions.get_first_mat(pieces_path + '/' + mat_txt)
        init_mat = init_mat[:3]
        w, h = functions.get_dims(mat_txt)

        print("final size: " + str(w) + "x" + str(h))
        pieces_path += '/pieces'
        imgs = os.listdir(pieces_path)
        pieces_number = len(imgs)
        piece_list = []

        for i in range(pieces_number):
            im = cv2.imread(pieces_path + '/piece_' + str(i + 1) + '.jpg')
            piece_list.append([i, im])
        print("got " + str(len(imgs)) + " puzzle pieces")

        if affine:
            newpath = 'results/puzzle_affine_' + str(file_num) + "/"
        else:
            newpath = 'results/puzzle_homography_' +str(file_num)+"/"
        if not os.path.exists(newpath):
            os.makedirs(newpath)

        im, pieces_used = functions.assemble_puzzle(piece_list, ratio=ratio, min_inlrs_prcntg=min_inlrs_prcntg,
                                                    satisfying_inlrs_prcntg=satisfying_inlrs_prcntg,
                                                    inlrs_dist=inlrs_dist, affine=affine, init_mat=init_mat,
                                                    w=w, h=h, sol_path=newpath)
        relative_places = []
        for relative in os.listdir(newpath):
            im_name = relative
            if 'relative' in im_name:
                im = cv2.imread(str(newpath + im_name))
                relative_places.append(im)
        coverage = functions.segment_images(relative_places)
        cv2.imwrite(newpath + "coverage.jpeg",
                    coverage, [cv2.IMWRITE_JPEG_QUALITY, 90])

        cv2.imwrite(newpath + "solution_" + str(pieces_used) + "_" + str(pieces_number) + ".jpeg",
                    im, [cv2.IMWRITE_JPEG_QUALITY, 90])
        print("saved solution image for puzzle " + str(file_num))


if __name__ == '__main__':
    old_puzzles = True
    if old_puzzles:
        solve_puzzle_files(path=AFFINE_MAIN_PATH, start=1, end=11, affine=True, ratio=0.6, min_inlrs_prcntg=0.75,
                           satisfying_inlrs_prcntg=0.95, inlrs_dist=1.5)
        solve_puzzle_files(path=HOMOGRAPHY_MAIN_PATH, start=1, end=11, affine=False, ratio=0.65, min_inlrs_prcntg=0.65,
                           satisfying_inlrs_prcntg=0.95, inlrs_dist=1)
    else:
        #change old_puzzles to false
        #copy puzzle path here and give it to argument path, choose the thresholds and if affine
        new_path = ""
        solve_puzzle_files(path=new_path, affine=True, ratio=0.65, min_inlrs_prcntg=0.65,
                           satisfying_inlrs_prcntg=0.95, inlrs_dist=1, new_puzzle=True)
